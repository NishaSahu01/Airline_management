module.exports={
    MONGOURI:"mongodb+srv:///nishasahu081203:mqkeRp9B3DMC454l@nisha.8asb8gv.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
};